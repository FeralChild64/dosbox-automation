# Language: Slovenian (CP852)
# Translated by Matej Horvat (http://matejhorvat.si/), last update 2013-04-29

0.0:Izpi�e vse vrstice datoteke, ki vsebujejo niz.
0.1:Pre�teje �tevilo vrstic, ki vzebujejo niz
0.2:Ne lo�i velikih in malih �rk
0.3:O�tevil�i prikazane vrstice, za�en�i z 1
0.4:Izpi�i vrstice, ki ne vsebujejo niza
1.0:datoteka
1.1:niz
2.0:Ni mogo�e odprti datoteke
2.1:Datoteka ne obstaja
2.2:Ni mogo�e zamenjati imenika
